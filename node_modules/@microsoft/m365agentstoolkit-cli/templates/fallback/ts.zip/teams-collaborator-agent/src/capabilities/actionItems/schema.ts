// Function schemas for the action items capability

// Not needed for this capability because it has no custom functions
