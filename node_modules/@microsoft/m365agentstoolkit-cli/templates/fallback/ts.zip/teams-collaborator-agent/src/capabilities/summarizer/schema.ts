// Function schemas for the summarizer

// Not needed for this capability because it has no custom functions
